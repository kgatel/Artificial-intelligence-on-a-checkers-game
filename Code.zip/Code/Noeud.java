
public abstract class Noeud {

	
public abstract int heuristique() ; //Donne la valeur du noeud 


}
