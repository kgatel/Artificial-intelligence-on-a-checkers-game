
public enum Couleur {
	
	Blanc,
	Noir,
	;
	
}