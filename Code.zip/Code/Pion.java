import java.awt.Color;
import java.awt.Graphics;

public class Pion extends Piece{

	//attributs


	public Pion(Couleur couleur,Coordonnees c, Damier damier) {
		super(couleur,c,damier);
	}

	public String toString() {
		return "pion";
	}

}
