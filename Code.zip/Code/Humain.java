
public class Humain extends Joueur{

	public Humain(Couleur couleur, String pseudo) {
		super(couleur,pseudo);
	}
	
}
